/**
 * DBD.JS v4 made by Leref.
 */

const Bot = require("../Handlers/Initial.js")

module.exports = Bot