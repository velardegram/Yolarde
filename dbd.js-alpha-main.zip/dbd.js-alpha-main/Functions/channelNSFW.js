module.exports = async (d) => {
	const unpacked = d.unpack();

	if (d.hasUsage(unpacked) && !(await d.data.main.utils.getChannel(unpacked.inside).catch((err) => null))) return d.error(`Invalid Channel ID \`${unpacked.inside}\` at \`${d.func}${unpacked.total}\``, `${d.func}${unpacked.total}`);

	return (d.hasUsage(unpacked) ? (await d.data.main.utils.getChannel(unpacked.inside).catch((e) => undefined))?.nsfw : d.data?.message?.channel?.nsfw)?.toString() || "false";
};
