const ms = require('parse-ms');

module.exports = () => {
	return function (d) {
		const time = ms(d.data.client.uptime);

		return `${time.days ? time.days + 'd' : ''} ${time.hours ? time.hours + 'h' : ''} ${time.minutes ? time.minutes + 'm' : ''} ${time.seconds ? time.seconds + 's' : ''}`.trim();
	};
};
