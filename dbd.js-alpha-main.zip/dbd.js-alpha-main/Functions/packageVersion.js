module.exports = async d => {
    return require("../package.json").version
    }