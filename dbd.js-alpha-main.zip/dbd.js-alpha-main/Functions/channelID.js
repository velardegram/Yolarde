module.exports = (d) => d.data.channel?.id || '';
