module.exports = (d) => d.data.client?.guilds?.cache?.reduce((x, y) => x + (y.memberCount - 1 || 0), 0) || 0;
