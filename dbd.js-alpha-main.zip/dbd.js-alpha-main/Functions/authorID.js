module.exports = (d) => {
	return d?.data?.message?.author?.id || '';
};
